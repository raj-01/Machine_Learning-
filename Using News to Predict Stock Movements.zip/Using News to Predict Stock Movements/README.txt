Using News to Predict Stock Movements ( Kaggle Competition 2019 )

Steps Involved :
1.) Using Clustering algorithm to collect separate news data from internet. ( This technique is currently used by Google to clustre different articles )

2.) Using document classification getting the bussiness news/document seprated from the collected news articles.

3.) Cleansing the data and converting it into CSV format usign Pandas.

4.) Stock Data Extraction and Retrival from the unstructured text data stored in pandas.

5.) Training regression models from the data obtain.

6.) Cross validation for the test data. 

6.) Real life cross validation.

7.) Checking for the best model out of all trained model.   


